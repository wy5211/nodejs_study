// 默认整体导出
// module.exports = {
//   a: 1,
//   b: 2,
//   fn: function () {
//     console.log("fn");
//   },
// };

// 导出单个的方法
exports.fn1 = () => {};
exports.fn2 = () => {};
